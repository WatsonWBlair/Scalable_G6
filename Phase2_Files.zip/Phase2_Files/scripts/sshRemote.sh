source .env

ssh -i $EC2_KEY_PATH $EC2_USER@$EC2_HOST